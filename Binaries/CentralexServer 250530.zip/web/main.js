window.onload = () => {
  const table_elem = document.getElementById("table");
  const last_change = document.getElementById("last_change");
  const last_ping = document.getElementById("last_ping");
  const connected = document.getElementById("connected");
  const free_ports = document.getElementById("free_ports");

  //const timeout_duration = 10 * 1000;
  //const retry_timeout = 5 * 1000;
  const update_intervall = 10; // 10 seconds

  let reconnect_timeout;
  let ping_timeout;
  let evtSource;
  let table_data;

  let lastUpdate = 0;
  let updateTimer = 0;

  const names = [
    "name",
    "number",
    "port",
    "status",
    "last_change",
  ];


  let sort_dir = -1;
  let sort_key = "last_change";
  //let sort_key = "number";
  const table_column = document.getElementById("table_" + sort_key);
  table_column.className = `sort sort-down`;


  const get_utc_now = () => {
    const now = new Date();
    return Math.trunc((now.getTime() - now.getTimezoneOffset()) / 1000);
  };


  const time_ago = (minutes) => {
    let unit = 0;
    let factors = [
      [1, "Sekunde", "n"],
      [60, "Minute", "n"],
      [60, "Stunde", "n"],
      [24, "Tag", "en"],
      [7, "Woche", "n"],
      [4.348214, "Monat", "en"],
      [12, "Jahr", "en"],
    ];

    for (let i in factors) {
      let factor = factors[i][0];
      const new_minutes = Math.floor(minutes / factor);
      if (new_minutes == 0) break;
      minutes = new_minutes;
      unit = i;
    }

    const factor = factors[unit];
    return [minutes, factors[unit][1] + (minutes == 1 ? "" : factor[2])];
  };
  

  sort = (element, key) => {
    const old_key = sort_key;
    if (key == sort_key) {
      sort_dir *= -1;
    } else {
      sort_key = key;
      sort_dir = 1;
    }

    const oldElement = document.getElementById(`table_${old_key}`);
    //console.log(oldElement);
    oldElement.className = "";
    const newElement = document.getElementById(`table_${key}`);
    //console.log(newElement);
    newElement.className = `sort ${sort_dir > 0 ? "sort-up" : "sort-down"}`

    do_sort(sort_key, sort_dir);
  };


  const do_sort = (key, dir) => {
    //console.log(key, dir);
    const is_number = !!~(["port", "number", "last_change"].indexOf(key));
    table_data.Clients = table_data.Clients.sort((a, b) => (dir * (
      is_number ? a[key] - b[key] : ("" + a[key]).localeCompare(b[key], "de-DE")
    )));

    populate_table();
  };


  const fmt = Intl.DateTimeFormat("de-DE", {
    dateStyle: "medium",
    timeStyle: "medium",
  });

  //const format_date = (date) => fmt.format(date).replace(", ", " ");
  //const format_time = (date) => fmt.format(date).split(", ", 2)[1];

  const populate_table = () => {
          
    console.log(table_data);

    free_ports.innerText = `Freie Ports: ${table_data.FreePorts}`;

    // clear everything except for the header row
    while (table_elem.rows.length > 1) {
      table_elem.deleteRow(-1);
    }
    
   const now = new Date();
   //const nowUtc = Math.trunc((now.getTime() - now.getTimezoneOffset()) / 1000);
   const nowUtc = get_utc_now();
    
   for (let row of table_data.Clients) {
      const tr = table_elem.insertRow(-1);

      //console.log(time_ago(nowUtc - row.last_change));

      const values = [
        row.name === null ? "?" : row.name,
        row.number,
        row.port,
        row.status,
        time_ago(nowUtc - row.last_change),
      ];

      for (let i in values) {
        const value = values[i];
        const name = names[i];
        const td = tr.insertCell(-1);
        td.className = name;

        if (name == "last_change") {
          const [number, unit] = value;
          let span = document.createElement("span");
          // span.className = "value";
          span.innerText = number;
          td.appendChild(span);

          span = document.createElement("span");
          span.className = "unit";
          span.innerText = unit;
          td.appendChild(span);
        } else {
          td.innerText = value;
        }
      }
    }
  };


  const update_table = (data) => {
    //console.log(data);
    table_data = data;
    //console.log(table_data);
    do_sort(sort_key, sort_dir);
    //populate_table();
  }


  //const format_event = (event, method) =>
  //  (method || format_date)(new Date(+event.data * 1000));

  let display_disconnected;

  /*
  const dumpJson = (json) => {
      console.log(json);
      return json;
  }
  */
  
  const checkUpdate = (lastChanged) => {
    const nowUtc = get_utc_now();
    
    //console.log(nowUtc - updateTimer);
    
    if (lastChanged.LastChanged > lastUpdate || nowUtc - updateTimer >= update_intervall) {
      fetch("/table")
        .then((res) => res.json())
        .then(update_table);
      lastUpdate = lastChanged.LastChanged;
      updateTimer = nowUtc;
    }
  }
  
  const myTimer = () => {
    //console.log("timer");
      
    fetch("/update")
      .then((res) => res.json())
      .then(checkUpdate);

    connected.className = "visible";
    last_ping.innerText = `Stand: ${new Date().toLocaleDateString("de-DE")} ${new Date().toLocaleTimeString("de-DE")}`;
  } 
 
  console.log("start timer");
  setInterval(myTimer, 1000);
};
